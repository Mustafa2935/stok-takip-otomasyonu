package com.example.stoktakip;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class StokListele extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private ArrayList<String> stokListesi = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stok_listele);

        mDatabase = FirebaseDatabase.getInstance().getReference().child("urunler");

        ListView stokListView = findViewById(R.id.listView);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, stokListesi);
        stokListView.setAdapter(adapter);

        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                stokListesi.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String kategori = snapshot.child("kategori").getValue(String.class);
                    String marka = snapshot.child("marka").getValue(String.class);
                    String barkodno = snapshot.child("barkodno").getValue(String.class);
                    String miktar = snapshot.child("miktar").getValue(String.class);
                    String alisfiyati = snapshot.child("alisfiyati").getValue(String.class);
                    String satisfiyati = snapshot.child("satisfiyati").getValue(String.class);

                    String stokBilgisi = "Kategori: " + kategori + "\nMarka: " + marka + "\nBarkod No: " + barkodno + "\nMiktar: " + miktar + "\nAlış Fiyatı: " + alisfiyati + " TL\nSatış Fiyatı: " + satisfiyati + " TL";
                    stokListesi.add(stokBilgisi);

                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }
}
