package com.example.stoktakip;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class Istatislikler extends AppCompatActivity {

    private RecyclerView recyclerViewStatistics;
    private StatisticsAdapter statisticsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_istatislikler);

        ImageSlider imageSlider = findViewById(R.id.ImageSlider);
        ArrayList<SlideModel> slideModels = new ArrayList<>();
        slideModels.add(new SlideModel(R.drawable.ilacilk, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.ilac1, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.ilac2, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.ilac3, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.ilac4, ScaleTypes.FIT));
        imageSlider.setImageList(slideModels, ScaleTypes.FIT);

        recyclerViewStatistics = findViewById(R.id.recyclerViewStatistics);

        recyclerViewStatistics.setLayoutManager(new LinearLayoutManager(this));

        List<StatisticItem> statisticItemList = new ArrayList<>();

        String currentDate = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(new Date());
        String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

        statisticItemList.add(new StatisticItem("Günlük Satış", "25", currentDate, currentTime));
        statisticItemList.add(new StatisticItem("Toplam Satış", "150", currentDate, currentTime));

        statisticsAdapter = new StatisticsAdapter(statisticItemList);

        recyclerViewStatistics.setAdapter(statisticsAdapter);
    }
}
