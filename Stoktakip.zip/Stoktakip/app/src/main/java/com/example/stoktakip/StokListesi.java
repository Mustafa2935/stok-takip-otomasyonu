package com.example.stoktakip;

import android.app.Activity;

public class StokListesi extends Activity {
}
