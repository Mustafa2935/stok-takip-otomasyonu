package com.example.stoktakip;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Islemgecmisi extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private List<String> islemListesi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_islemgecmisi);

        mDatabase = FirebaseDatabase.getInstance().getReference().child("satislar");
        listView = findViewById(R.id.listView);
        islemListesi = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, islemListesi);
        listView.setAdapter(adapter);

        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                islemListesi.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String isimSoyisim = snapshot.child("isimSoyisim").getValue(String.class);
                    String tc = snapshot.child("tc").getValue(String.class);
                    String adres = snapshot.child("adres").getValue(String.class);
                    String barkodNo = snapshot.child("barkodNo").getValue(String.class);
                    String miktar = snapshot.child("miktar").getValue(String.class);
                    String kategori = snapshot.child("kategori").getValue(String.class);
                    String marka = snapshot.child("marka").getValue(String.class);
                    String satisBilgisi = "İsim Soyisim: " + isimSoyisim + "\nTC: " + tc + "\nAdres: " + adres +
                            "\nBarkod No: " + barkodNo + "\nMiktar: " + miktar + "\nKategori: " + kategori + "\nMarka: " + marka;
                    islemListesi.add(satisBilgisi);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
