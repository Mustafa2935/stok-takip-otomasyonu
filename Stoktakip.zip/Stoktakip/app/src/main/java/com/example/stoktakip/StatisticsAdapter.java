package com.example.stoktakip;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class StatisticsAdapter extends RecyclerView.Adapter<StatisticsAdapter.ViewHolder> {

    private List<StatisticItem> statisticItems;
    private Context context;

    public StatisticsAdapter(List<StatisticItem> statisticItems) {
        this.context = context;
        this.statisticItems = statisticItems;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_statistic, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        StatisticItem item = statisticItems.get(position);
        holder.textViewTitle.setText(item.getTitle());
        holder.textViewValue.setText(item.getValue());
    }

    @Override
    public int getItemCount() {
        return statisticItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView textViewTitle;
        TextView textViewValue;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewTitle = itemView.findViewById(R.id.text_view_title);
            textViewValue = itemView.findViewById(R.id.text_view_value);
        }
    }
}
