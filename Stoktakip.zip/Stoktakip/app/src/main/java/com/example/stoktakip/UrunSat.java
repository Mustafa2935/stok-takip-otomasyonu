package com.example.stoktakip;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class UrunSat extends AppCompatActivity {

    private EditText editTextIsimSoyisim, editTextTC, editTextAdres, editTextBarkodNo, editTextMiktar;
    private Spinner spinnerKategori, spinnerMarka;
    private DatabaseReference mDatabase;
    private int satisCounter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_urun_sat);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        mDatabase.child("satis_sayisi").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    satisCounter = dataSnapshot.getValue(Integer.class);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

        // EditText ve Spinner bileşenlerini bulma
        editTextIsimSoyisim = findViewById(R.id.editTextText5);
        editTextTC = findViewById(R.id.editTextText6);
        editTextAdres = findViewById(R.id.editTextText7);
        editTextBarkodNo = findViewById(R.id.editTextText8);
        editTextMiktar = findViewById(R.id.editTextText9);
        spinnerKategori = findViewById(R.id.spinner1);
        spinnerMarka = findViewById(R.id.spinner2);

        String[] kategoriler = {"Ağrı Kesici", "Soğuk Algınlığı", "Antibiyotik", "Ateş Düşürücü", "C Vitamini"};
        ArrayAdapter<String> adapterKategori = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, kategoriler);
        adapterKategori.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerKategori.setAdapter(adapterKategori);

        String[] markalar = {"Dolarex", "İburomin Cold", "Anti Fes", "Pedifen", "Rodoxon"};
        ArrayAdapter<String> adapterMarka = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, markalar);
        adapterMarka.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMarka.setAdapter(adapterMarka);

        Button buttonSat = findViewById(R.id.button);
        buttonSat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                urunSat();
            }
        });
    }

    private void urunSat() {
        final String isimSoyisim = editTextIsimSoyisim.getText().toString();
        final String tc = editTextTC.getText().toString();
        final String adres = editTextAdres.getText().toString();
        final String barkodNo = editTextBarkodNo.getText().toString();
        final String miktar = editTextMiktar.getText().toString();
        final String kategori = spinnerKategori.getSelectedItem().toString();
        final String marka = spinnerMarka.getSelectedItem().toString();

        if (isimSoyisim.isEmpty() || tc.isEmpty() || adres.isEmpty() || barkodNo.isEmpty() || miktar.isEmpty()) {
            Toast.makeText(this, "Lütfen tüm alanları doldurun!", Toast.LENGTH_SHORT).show();
        } else {
            mDatabase.child("urunler").orderByChild("barkodno").equalTo(barkodNo).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            String urunKey = snapshot.getKey();
                            int urunMiktari = Integer.parseInt(snapshot.child("miktar").getValue(String.class));
                            int satilanMiktar = Integer.parseInt(miktar);
                            int kalanMiktar = urunMiktari - satilanMiktar;
                            if (kalanMiktar >= 0) {
                                mDatabase.child("urunler").child(urunKey).child("miktar").setValue(String.valueOf(kalanMiktar));
                            } else {
                                Toast.makeText(UrunSat.this, "Stokta yeterli ürün bulunmamaktadır!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        String satisNumarasi = "satis" + (++satisCounter);
                        mDatabase.child("satislar").child(satisNumarasi).child("isimSoyisim").setValue(isimSoyisim);
                        mDatabase.child("satislar").child(satisNumarasi).child("tc").setValue(tc);
                        mDatabase.child("satislar").child(satisNumarasi).child("adres").setValue(adres);
                        mDatabase.child("satislar").child(satisNumarasi).child("barkodNo").setValue(barkodNo);
                        mDatabase.child("satislar").child(satisNumarasi).child("miktar").setValue(miktar);
                        mDatabase.child("satislar").child(satisNumarasi).child("kategori").setValue(kategori);
                        mDatabase.child("satislar").child(satisNumarasi).child("marka").setValue(marka);
                        mDatabase.child("satis_sayisi").setValue(satisCounter); // Satış sayısını güncelle
                        Toast.makeText(UrunSat.this, "Ürün satışı başarıyla gerçekleştirildi!", Toast.LENGTH_SHORT).show();
                        editTextIsimSoyisim.setText("");
                        editTextTC.setText("");
                        editTextAdres.setText("");
                        editTextBarkodNo.setText("");
                        editTextMiktar.setText("");
                    } else {
                        Toast.makeText(UrunSat.this, "Böyle bir ürün bulunamadı!", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        }
    }
}
