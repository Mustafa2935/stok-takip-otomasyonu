package com.example.stoktakip;

import android.app.Activity;

public class Ana_SayfaActivity extends Activity {
}
