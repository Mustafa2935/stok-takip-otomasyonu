package com.example.stoktakip;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class UrunAl extends ComponentActivity {
    private DatabaseReference mDatabase;
    private int siparisCounter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_urun_al);

        mDatabase = FirebaseDatabase.getInstance().getReference();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Spinner spinner1 = findViewById(R.id.spinner1);
        String[] kategoriler = {"Ağrı Kesici", "Soğuk Algınlığı", "Antibiyotik", "Ateş Düşürücü", "C Vitamini"};
        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, kategoriler);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter1);

        Spinner spinner2 = findViewById(R.id.spinner2);
        String[] markalar = {"Dolarex", "İburomin Cold", "Anti Fes", "Pedifen", "Rodoxon"};
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, markalar);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);

        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        siparisCounter = sharedPref.getInt("siparisCounter", 1);

        Button urunAlButton = findViewById(R.id.urun_al_button);
        urunAlButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                urunAl();
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt("siparisCounter", siparisCounter);
        editor.apply();
    }

    private void urunAl() {
        Spinner spinner1 = findViewById(R.id.spinner1);
        String kategori = spinner1.getSelectedItem().toString();

        Spinner spinner2 = findViewById(R.id.spinner2);
        String marka = spinner2.getSelectedItem().toString();

        EditText editText3 = findViewById(R.id.editTextText3);
        String barkodno = editText3.getText().toString();

        EditText editText2 = findViewById(R.id.editTextText2);
        String miktar = editText2.getText().toString();

        EditText editText = findViewById(R.id.editTextText);
        String alisfiyati = editText.getText().toString();

        EditText editText4 = findViewById(R.id.editTextText4);
        String satisfiyati = editText4.getText().toString();

        if (kategori.isEmpty() || marka.isEmpty() || barkodno.isEmpty() || miktar.isEmpty()|| alisfiyati.isEmpty()|| satisfiyati.isEmpty()) {
            Toast.makeText(this, "Lütfen tüm alanları doldurun!", Toast.LENGTH_SHORT).show();
        } else {
            String siparisNumarasi = "siparis" + siparisCounter;

            mDatabase.child("urunler").child(siparisNumarasi).child("barkodno").setValue(barkodno);
            mDatabase.child("urunler").child(siparisNumarasi).child("kategori").setValue(kategori);
            mDatabase.child("urunler").child(siparisNumarasi).child("marka").setValue(marka);
            mDatabase.child("urunler").child(siparisNumarasi).child("miktar").setValue(miktar);
            mDatabase.child("urunler").child(siparisNumarasi).child("alisfiyati").setValue(alisfiyati);
            mDatabase.child("urunler").child(siparisNumarasi).child("satisfiyati").setValue(satisfiyati);

            siparisCounter++;

            Toast.makeText(this, "Ürün başarıyla alındı!", Toast.LENGTH_SHORT).show();

            editText3.setText("");
            editText2.setText("");
            editText.setText("");
            editText4.setText("");
        }
    }
}
